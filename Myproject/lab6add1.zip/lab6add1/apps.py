from django.apps import AppConfig


class lab6add1Config(AppConfig):
    name = 'lab6add1'
